"""
Pydantic schemas for the Detection feature.

`DetectionType` centralizes the set of detection rule names so future
detections (e.g. impossible travel, unusual device) reuse the same
enum instead of hardcoding strings across the codebase.

`BruteForceDetection` is the response shape for brute-force results.
It's deliberately generic enough (detection_type, risk_score) that
other detection rules can reuse the same base shape later, which
keeps this feature modular for when Incidents are built on top of it.
"""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class DetectionType(str, Enum):
    BRUTE_FORCE = "Brute Force"


class BruteForceDetection(BaseModel):
    """A single brute-force detection result for one username."""

    detection_type: DetectionType = Field(default=DetectionType.BRUTE_FORCE)
    username: str
    failed_attempts: int = Field(..., ge=1, description="Number of failed logins in the detected window")
    risk_score: int = Field(..., description="Fixed severity score assigned to this detection type")
    first_attempt_timestamp: datetime
    last_attempt_timestamp: datetime
