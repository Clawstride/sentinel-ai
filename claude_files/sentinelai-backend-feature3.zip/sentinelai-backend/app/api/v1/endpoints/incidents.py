"""
Incident Management endpoints.

- POST /incidents/generate  — runs brute-force detection and creates
  Incident records from the results.
- GET  /incidents           — lists all incidents, newest first.
- GET  /incidents/{incident_id} — fetches a single incident.

These endpoints only handle HTTP concerns (DB session, dependency
wiring, 404 translation) — all business logic lives in IncidentService.
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.repositories.incident_repository import IncidentRepository
from app.repositories.log_event_repository import LogEventRepository
from app.schemas.incident import IncidentGenerateResponse, IncidentRead
from app.services.detection.brute_force_detection_service import BruteForceDetectionService
from app.services.incident_service import IncidentService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/incidents", tags=["Incidents"])


def get_incident_service(db: Session = Depends(get_db)) -> IncidentService:
    """Wires repositories and the existing detection service into IncidentService."""
    incident_repository = IncidentRepository(db)
    log_event_repository = LogEventRepository(db)
    detection_service = BruteForceDetectionService(log_event_repository)
    return IncidentService(incident_repository, detection_service, db)


@router.post(
    "/generate",
    response_model=IncidentGenerateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Generate incidents from brute-force detections",
)
def generate_incidents(
    service: IncidentService = Depends(get_incident_service),
) -> IncidentGenerateResponse:
    """
    Runs the existing brute-force detection service and creates one
    Incident per detected burst that doesn't already have one.
    """
    incidents_created = service.generate_from_bruteforce_detections()
    return IncidentGenerateResponse(
        message="Incident generation completed",
        incidents_created=incidents_created,
    )


@router.get(
    "",
    response_model=list[IncidentRead],
    summary="List all incidents (newest first)",
)
def list_incidents(service: IncidentService = Depends(get_incident_service)) -> list[IncidentRead]:
    """Returns every incident, ordered by creation time descending."""
    return service.list_incidents()


@router.get(
    "/{incident_id}",
    response_model=IncidentRead,
    summary="Get a single incident by incident_id",
)
def get_incident(incident_id: str, service: IncidentService = Depends(get_incident_service)) -> IncidentRead:
    """Returns one incident by its human-friendly ID, e.g. 'INC-000001'."""
    incident = service.get_incident(incident_id)
    if incident is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident '{incident_id}' not found.",
        )
    return incident
