"""
Detection endpoints.

GET /detections/bruteforce runs the brute-force detection rule over
stored authentication logs and returns the results. This endpoint only
handles HTTP concerns (DB session, dependency wiring) — the detection
logic itself lives in the service layer.
"""

import logging

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.repositories.log_event_repository import LogEventRepository
from app.schemas.detection import BruteForceDetection
from app.services.detection.brute_force_detection_service import BruteForceDetectionService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/detections", tags=["Detections"])


def get_bruteforce_detection_service(db: Session = Depends(get_db)) -> BruteForceDetectionService:
    """Wires the repository into the detection service (manual DI, matching the rest of the app)."""
    repository = LogEventRepository(db)
    return BruteForceDetectionService(repository)


@router.get(
    "/bruteforce",
    response_model=list[BruteForceDetection],
    summary="Detect brute-force login attempts",
)
def get_bruteforce_detections(
    service: BruteForceDetectionService = Depends(get_bruteforce_detection_service),
) -> list[BruteForceDetection]:
    """
    Scans stored authentication logs for brute-force patterns: 5 or
    more failed login attempts by the same username within a rolling
    10-minute window. Returns one result per detected burst.
    """
    return service.detect()
