"""
Service layer for the Incident Management module.

Turns detection results into persisted Incident records. This module
calls the existing BruteForceDetectionService exactly as-is (no
changes to it) and treats it purely as a data source — future
detection rules can be added here the same way, without touching this
service's public interface.
"""

import logging

from sqlalchemy.orm import Session

from app.models.incident import Incident
from app.models.log_event import LogEvent
from app.repositories.incident_repository import IncidentRepository
from app.schemas.detection import BruteForceDetection
from app.services.detection.brute_force_detection_service import BruteForceDetectionService

logger = logging.getLogger(__name__)


class IncidentService:
    """Coordinates turning detection results into Incident records."""

    def __init__(
        self,
        repository: IncidentRepository,
        detection_service: BruteForceDetectionService,
        db: Session,
    ):
        self.repository = repository
        self.detection_service = detection_service
        # A read-only lookup against LogEvent (to find the source IP for a
        # detection) is done directly here rather than via LogEventRepository,
        # so that repository — part of the already-complete upload feature —
        # is left untouched.
        self.db = db

    def generate_from_bruteforce_detections(self) -> int:
        """
        Runs brute-force detection and creates an Incident for every
        detection that doesn't already have one. Returns the number of
        incidents created (0 if all detections already have incidents,
        or if no detections were found).
        """
        detections = self.detection_service.detect()

        created_count = 0
        for detection in detections:
            title = self._build_title(detection)

            if self.repository.exists(
                username=detection.username,
                incident_type=detection.detection_type.value,
                title=title,
            ):
                logger.info(f"Incident already exists for {detection.username!r} window, skipping")
                continue

            incident = Incident(
                incident_id="PENDING",  # overwritten with INC-000001 style ID on create()
                title=title,
                incident_type=detection.detection_type.value,
                severity=self._map_severity(detection.risk_score),
                risk_score=detection.risk_score,
                status="Open",
                username=detection.username,
                source_ip=self._lookup_source_ip(detection),
            )
            self.repository.create(incident)
            created_count += 1

        logger.info(f"Incident generation created {created_count} new incident(s)")
        return created_count

    def list_incidents(self) -> list[Incident]:
        """Returns all incidents, newest first."""
        return self.repository.get_all()

    def get_incident(self, incident_id: str) -> Incident | None:
        """Returns a single incident by its incident_id, or None if not found."""
        return self.repository.get_by_incident_id(incident_id)

    @staticmethod
    def _build_title(detection: BruteForceDetection) -> str:
        """
        Builds a descriptive, deterministic title that encodes the
        detected time window, so the same burst never creates two
        incidents but two distinct bursts for the same user do.
        """
        return (
            f"Brute Force Login Attempts Detected for '{detection.username}' "
            f"({detection.first_attempt_timestamp.isoformat()} to "
            f"{detection.last_attempt_timestamp.isoformat()})"
        )

    @staticmethod
    def _map_severity(risk_score: int) -> str:
        """Maps a numeric risk score to a severity label."""
        if risk_score >= 70:
            return "High"
        if risk_score >= 40:
            return "Medium"
        return "Low"

    def _lookup_source_ip(self, detection: BruteForceDetection) -> str | None:
        """Finds the source IP of the earliest failed login within the detected window."""
        event = (
            self.db.query(LogEvent)
            .filter(
                LogEvent.username == detection.username,
                LogEvent.timestamp >= detection.first_attempt_timestamp,
                LogEvent.timestamp <= detection.last_attempt_timestamp,
            )
            .order_by(LogEvent.timestamp.asc())
            .first()
        )
        return event.ip_address if event else None
